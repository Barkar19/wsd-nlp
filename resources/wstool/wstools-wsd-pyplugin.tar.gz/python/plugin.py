import os, ConfigParser, logging
from wosedon import wosedon_plugin

CONFIG_PATH = os.path.join(
  os.path.abspath(os.path.dirname(__file__)), 
  'config.ini')

class Plugin():
  def __init__(self):
    """!
    Initial method.

    Makes the WosedonPlugin opbject and store it as a member.
    WoSeDonPlugin logs the debug informations about the initializing,
    reading config etc into debug level.
    """
    try:
      config = self._read_config(CONFIG_PATH)
      self.wsdlg = wosedon_plugin.WoSeDonPlugin(
        config.get('options', 'wosedon_cfg_file'), 
        config.get('options', 'wosedon_model_dir'))
    except Exception, e:
      logging.debug(str(e))
      exit(1)

  def _read_config(self, cfg_path):
    """!
    Reads config file: section for worker and also for Wosedon

    @param cfg_path Path to config file
    @type String
    @return Read config file
    @rtype: Config 
    """
    with open(cfg_path) as config_file:
      config = ConfigParser.RawConfigParser()
      config.readfp(config_file)
    return config

  def process(self, inccl, outccl, options=None):
    """!
    Runs WoSeDonPlugin method to makes disambiguations

    @param inccl Path to input CCL file
    @type inccl: String
    @param outccl Path to output CCL file
    @type outccl: String
    @param options Additional options
    @type options: ?? As default are set to None
    """
    logging.debug("WoSeDon is processing file: %s" % inccl)
    self.wsdlg.run_wosedon(inccl, outccl, options)


if __name__ == '__main__':
  p = Plugin()
  p.process(
    '/home/pkedzia/zolc/1.ccl',
    '/home/pkedzia/zolc/1out.ccl',
    [])